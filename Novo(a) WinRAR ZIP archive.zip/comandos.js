exports.functions = ('Corona, form, say, requisitos, anunciar, botinfo, ip, limpar, ping, serverinfo, sugestão, userinfo, mcserver, online, aplicação, equipe, setprefix, setregistro, new, report')

exports.admin = ('Mute, kick, ban, banir, unban, unmute, lock, unlock, promover, alert, aprovar')